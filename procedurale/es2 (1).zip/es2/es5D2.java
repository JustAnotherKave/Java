//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.



import java.util.Scanner;
public class es5D2 {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        int A;
        int B;
        int risultato;
        System.out.println("Farò la differenza tra A e B. Condizioni da rispettare: Numeri naturali e diversi");
        System.out.println("Inserisci A:");
        A=scanner.nextInt();
        System.out.println("Inserisci B:");
        B=scanner.nextInt();

        if(A >-1 && B>-1 && A!=B){

            if(A>B){
                risultato=A-B;
                System.out.println("La somma tra A: "+A+"e B: "+B+" è:" + risultato);

            }
            else{
                risultato=B-A;
                System.out.println("La somma tra A: "+A+"e B: "+B+" è:" + risultato);
            }

        }
        else{
            System.out.println("Le condizioni non sono rispettate");

        }


    }
}