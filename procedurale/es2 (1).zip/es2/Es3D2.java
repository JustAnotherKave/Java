/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es3d2;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es3D2 {

    /**
     * @param args the command line arguments
     */
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        // TODO code application logic here
        int A;
        int B;
        System.out.println("Inserisci A:");
        A=scanner.nextInt();
        System.out.println("Inserisci B:");
        B=scanner.nextInt();
        
        
        if(A == B-1){
            System.out.println("A è il numero precedente di B");
            
        }
        else{
            System.out.println("A non è il numero precedente di B");
        }
    }
    
}
