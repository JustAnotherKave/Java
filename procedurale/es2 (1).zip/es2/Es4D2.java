/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es4d2;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es4D2 {

    /**
     * @param args the command line arguments
     */
    
    static Scanner scanner= new Scanner(System.in);
    
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b;
        System.out.println("Insersci A:");
        a=scanner.nextInt();
        System.out.println("Inserisci B:");
        b=scanner.nextInt();
        
        if(a<b){
            System.out.println("A < B");
        }
        else if(a==b){
            System.out.println("A==B");
            
        }
        else{
            System.out.println("A>B");
        }
    }
    
}
