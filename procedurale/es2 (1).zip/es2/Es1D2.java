/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es1.pkg2;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es1D2 {

    /**
     * @param args the command line arguments
     */
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        int eta�;
        System.out.println("Inserisci l'età di una persona, e vedi se può votare o meno");
        età=scanner.nextInt();
        
        if(eta�<18){
            System.out.println("Non può partecipare alle elezioni");
        }
        else{
            System.out.println("Può partecipare alle elezioni");
        }
        
    }
    
}
