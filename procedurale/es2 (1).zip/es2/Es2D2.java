/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es2d2;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es2D2 {

    /**
     * @param args the command line arguments
     */
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        // TODO code application logic here
        int A;
        int B;
        System.out.println("Inserisci a : ");
        A=scanner.nextInt();
        
        System.out.println("Inserisci B:");
        B=scanner.nextInt();
        
        if(B*B==A){
            System.out.println("A è il quadrato di B");
            
        }
        else{
            System.out.println("A non è quadrato di B");
        }
        
    }
    
}
