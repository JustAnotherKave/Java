//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

public class es6D2 {
    public static void main(String[] args) {


        double lunghezza = 4.5;
        double larghezza = 3.0;
        double altezza = 2.8;


        double rotoloLunghezza = 10.05;
        double rotoloAltezza = 0.53;


        int prezzoNormale = 24;
        int prezzoExtra = 30;
        int prezzoExtraFine = 34;


        double perimetro = 2 * (lunghezza + larghezza);
        double areaPareti = perimetro * altezza;


        double areaRotolo = rotoloLunghezza * rotoloAltezza;


        int rotoli = (int)Math.ceil(areaPareti / areaRotolo);


        int costoNormale = rotoli * prezzoNormale;
        int costoExtra = rotoli * prezzoExtra;
        int costoExtraFine = rotoli * prezzoExtraFine;


        System.out.println("Scelta: tappezzare solo le pareti");
        System.out.println("Area totale pareti: " + areaPareti + " mq");
        System.out.println("Rotoli necessari: " + rotoli);
        System.out.println("Costo carta normale: " + costoNormale + " €");
        System.out.println("Costo carta extra: " + costoExtra + " €");
        System.out.println("Costo carta extra-fine: " + costoExtraFine + " €");
    }
}