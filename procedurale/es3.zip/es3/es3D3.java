//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

public class es3D3 {
    static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args) {
    int SommaD=0;
    int N;
    while(SommaD<=100){
        N=scanner.nextInt();
        if(N%2==0 ) {
            SommaD += N;
        }
    }
    System.out.println("Somma finale (>=100): " + SommaD);


    int pariCount = 0;
    int numero;

    System.out.println("\nInserisci numeri (termina con un dispari):");

    while (true) {
        System.out.print("Numero: ");
        numero = scanner.nextInt();

        if (numero % 2 != 0) { // dispari
            break;
        }
        else {
            pariCount++;
        }
    }

    System.out.println("Hai inserito " + pariCount + " numeri pari prima del dispari.");

    }
}