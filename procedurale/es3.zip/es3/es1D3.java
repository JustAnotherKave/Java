import java.util.Scanner;
public class es1D3 {
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {

        int Cont=1;
        int N;
        float media=0;
        int somma=0;
        System.out.println("Inserisci i numeri e ti calcolerò ogni volta la media(se inserisci un n<0 il programma terminerà");

        do{
            System.out.println("inserisci i numeri");
            N=scanner.nextInt();
            somma+=N;
            media=somma/Cont;
            Cont++;
            System.out.println("La media attuale è: "+media);
        }while(N>0);



    }
}