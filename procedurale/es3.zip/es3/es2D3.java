
import java.util.Scanner;
public class es2D3 {
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        int dim=0;
        int N=0;
        int sommaP=0;
        int sommaD=0;
        int mediaP=0;
        int mediaD=0;
        int NumeroPiccolo=0;
        int contP=0;
        int contD=0;
        System.out.println("Quanti numeri vuoi inserire?");
        dim=scanner.nextInt();
        for(int i=0;i<dim;i++){
            System.out.println("inserisci il numero");
            N=scanner.nextInt();
            if(N%2==0){
                sommaP+=N;
                contP++;
            }
            else{
                sommaD+=N;
                contD++;
            }

        }
        mediaP=sommaP/contP;
        mediaD=sommaD/contD;

        System.out.println("Somma pari:"+sommaP);
        System.out.println("Somma dispari:"+sommaD);
        System.out.println("Media Pari:"+mediaP);
        System.out.println("Media Dispari:"+mediaD);
    }
}