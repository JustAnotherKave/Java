import java.util.Scanner;


public class es4D6 {
    static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args) {
    int dim;
    int cont=0;
    int voto;
    int somma=0;
    int media=0;
    int max=1;
    int min=10;
    System.out.println("inserisci quanti voti vuoi inserire");
    dim=scanner.nextInt();
    System.out.println("inserisci i voti");
    do{
        voto=scanner.nextInt();

        somma+=voto;
        cont++;
        if (voto < min) {
            min = voto;
        }

        if (voto > max) {
            max = voto;
        }
    }while(voto>1 && voto<10 && cont<dim);
    media=somma/dim;
    System.out.println("La media è:"+media);

    }

}