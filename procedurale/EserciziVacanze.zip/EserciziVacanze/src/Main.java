import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner obj = new Scanner(System.in);

        // ESERCIZIO 1
        System.out.println("ESERCIZIO 1");

        final int N = 5;
        int[] a = {1, 2, 3, 4, 5};
        int[] b = new int[N];

        int j = N - 1;
        for (int i = 0; i < N; i++) {
            b[j] = a[i];
            j--;
        }

        // Copia b in a
        for (int i = 0; i < N; i++) {
            a[i] = b[i];
        }

        System.out.println("Array invertito:");
        for (int i = 0; i < N; i++) {
            System.out.println(a[i]);
        }

        // ESERCIZIO 2
        System.out.println("\nESERCIZIO 2");

        int[] array2 = new int[10];

        for (int i = 0; i < array2.length; i++) {
            array2[i] = i;
        }

        for (int i = 0; i < array2.length; i++) {
            System.out.println(array2[i]);
        }

        // ESERCIZIO 3
        System.out.println("\nESERCIZIO 3");

        int[] array3 = new int[100];

        for (int i = 0; i < 100; i++) {
            array3[i] = 99 - i;
        }

        System.out.println("Primi 100 numeri naturali in ordine inverso:");
        for (int i = 0; i < 100; i++) {
            System.out.print(array3[i] + " ");
        }

        // ESERCIZIO 4
        System.out.println("\n\nESERCIZIO 4");

        final int N4 = 5;
        int[] array4 = new int[N4];

        System.out.println("Inserisci 5 numeri:");

        for (int i = 0; i < N4; i++) {
            array4[i] = obj.nextInt();
        }

        System.out.println("Quale numero vuoi cercare?");
        int scelta = obj.nextInt();

        int cont4 = 0;

        for (int i = 0; i < N4; i++) {
            if (array4[i] == scelta) {
                cont4++;
            }
        }

        System.out.println("Il numero " + scelta + " compare " + cont4 + " volte.");

        // ESERCIZIO 5
        System.out.println("\nESERCIZIO 5");

        final int N5 = 10;
        int[] numeri = new int[N5];

        int negativi = 0;

        System.out.println("Inserisci " + N5 + " numeri:");

        for (int i = 0; i < N5; i++) {
            numeri[i] = obj.nextInt();

            if (numeri[i] < 0) {
                negativi++;
            }
        }

        System.out.println("I numeri negativi sono: " + negativi);

        // ESERCIZIO 6
        System.out.println("\nESERCIZIO 6");
        int[] A6= new int[8];
        int cont6=0;
        for(int i=0;i<A6.length;i++){
            A6[i]=obj.nextInt();
        }
        for(int i=0;i<A6.length;i++){
            if(A6[i]>23 && A6[i]<5){
                cont6++;
            }
        }
        System.out.println("I numeri compresi sono:"+cont6);
        // ESERCIZIO 7
        System.out.println("esercizio 7");
        int[] A7= new int[6];
        int contS=0;
        int contI=0;

        for (int i=0;i<A7.length;i++){
            A7[i]= obj.nextInt();
            if(A7[i]>8){

                contS++;
            }
            else if(A7[i]<8){
                contI++;
            }
        }
        System.out.println("I numeri superiori a 8 equivalgono a:"+contS+" e quelli inferiori:"+contI);


        //es8
        System.out.println("es 8");
        int[] A8= new int[8];
        int somma=0;
        A8[0]=1;
        A8[1]=4;
        A8[2]=4;
        A8[3]=-22;
        A8[4]=3;
        A8[5]=-7;
        A8[6]=5;
        A8[7]=-1;

        for(int i=0;i<A8.length;i++){
            if(A8[i]<0){
                somma+=A8[i];
                A8[i]=0;
            }
            System.out.println(A8[i]);
        }
        System.out.println(somma);


        //es9
        System.out.println("es9");
        System.out.print("Quanti studenti ci sono? ");
        int N9 = obj.nextInt();

        // Array dei nomi
        String[] nomi = new String[N9];

        // Matrice dei voti (5 voti per studente)
        double[][] voti = new double[N9][5];

        // Array delle medie
        double[] media = new double[N9];

        // Inserimento dati
        for (int i = 0; i < N9; i++) {
            System.out.print("\nNome studente " + (i + 1) + ": ");
            nomi[i] = obj.nextLine();

            double somma9 = 0;

            System.out.println("Inserisci i 5 voti:");

            for (int n = 0; n < 5; n++) {
                System.out.print("Voto " + (n + 1) + ": ");
                voti[i][n] = obj.nextDouble();
                somma9 += voti[i][n];
            }

            media[i] = somma9 / 5;
            obj.nextLine(); // svuota il buffer
        }

        // Calcolo media globale
        double sommaMedie = 0;

        for (int i = 0; i < N9; i++) {
            sommaMedie += media[i];
        }

        double mediaGlobale = sommaMedie / N9;

        // Stampa tabella
        System.out.println("\n----------------------------------------------");
        System.out.println("Nome\t\tMedia\tGiudizio");
        System.out.println("----------------------------------------------");

        for (int i = 0; i < N9; i++) {

            String giudizio;

            if (media[i] < 6) {
                giudizio = "Insufficiente";
            }
            else if (media[i] < 7) {
                giudizio = "Sufficiente";
            }
            else if (media[i] < 8) {
                giudizio = "Buono";
            }
                else if (media[i] < 9) {
                giudizio = "Distinto";
            }else {
                giudizio = "Ottimo";
            }
            System.out.println("info studente:"+ nomi[i]+ media[i]+ giudizio);
        }
        System.out.printf("Media globale della classe: "+ mediaGlobale);


        System.out.println("------------------------------------------------");
        System.out.println("es10");
        {
            int[][] A=new int[3][4];
            int Somma=0;
            for(int i=0;i<A.length;i++){
                for(int J = 0; J <A.length; J++){
                    A[i][J]= obj.nextInt();
                }
            }
            for(int i=0;i<A.length;i++){
                for(int J = 0; J <A.length; J++){
                    System.out.println(A[i][J]);
                }
            }
            for(int i=0;i<A.length;i++){
                for(int J=0;J<A.length;J++){
                    somma+=A[i][J];
                }
            }
            System.out.println(somma);
        }
        System.out.print("Inserisci il numero di righe: ");
        int righe = obj.nextInt();
        System.out.print("Inserisci il numero di colonne: ");
        int colonne = obj.nextInt();

        int[][] A11 = new int[righe][colonne];

        // 1. Lettura dei dati nella matrice
        System.out.println("Inserisci i numeri della tabella:");
        for (int i = 0; i < righe; i++) {
            for (int J = 0; J < colonne; J++) {
                A11[i][J] = obj.nextInt();
            }
        }
        //es11
        System.out.println("------------------------------------------");
        System.out.println("es11");
        int maxLine = 0;
        int maxSum = 0;

        // 2. Calcolo della somma per ciascuna riga
        for (int i = 0; i < righe; i++) {
            int sommaCorrente = 0;
            for (int J = 0; J < colonne; J++) {
                sommaCorrente += A11[i][J];
            }

            // Inizializza al primo ciclo (i == 0) o aggiorna se trova una somma maggiore
            if (i == 0 || sommaCorrente > maxSum) {
                maxSum = sommaCorrente;
                maxLine = i;
            }
        }

        // 3. Stampa dei risultati
        System.out.println("\nSOMMA MASSIMA: " + maxSum);
        System.out.println("NELLA RIGA: " + (maxLine + 1));

        System.out.print("CONTENUTO: ");
        for (int J = 0; J < colonne; J++) {
            System.out.print(A11[maxLine][J] + " ");
        }




    }

}

