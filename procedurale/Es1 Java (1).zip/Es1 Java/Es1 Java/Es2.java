/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es2;

/**
 *
 * @author Studente
 */
public class Es2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int altezza=15;
        int perimetro=40;
        int base=0;
        int area=0;
        System.out.println("Calcoliamo l'area, ma prima calcoliamo la base");
        base=(perimetro -(2*altezza))/2;
        System.out.println("la tua base e' " + base);
        System.out.println("ora calcoliamo l'area");
        area=base*altezza;
        System.out.println(area);
    }
    
}
