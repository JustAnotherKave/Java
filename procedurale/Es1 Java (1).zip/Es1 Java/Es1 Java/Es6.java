/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es6;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es6 {

    /**
     * @param args the command line arguments
     */
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
          int grandezzaNave=0;
          int permanenza=0;
          int costo=0;
        System.out.println("Deve imbarcare una nave, inserisci la permanenza e la altezza");
        
            System.out.println("Inserisci la permanenza");
            permanenza=scanner.nextInt();
            System.out.println("Ora l'altezza");
            grandezzaNave=scanner.nextInt();
        
        if(grandezzaNave<=5){
            costo=15*permanenza;
            System.out.println(costo);
        }
        else if(grandezzaNave<=12){
            costo=22*permanenza;
            System.out.println(costo);
        }
        else if(grandezzaNave<=30){
            costo=30*permanenza;
            System.out.println(costo);
        }
        else if(grandezzaNave>30){
            costo=45*permanenza;
            System.out.println(costo);
        }
        // TODO code application logic here
    }
    
}

