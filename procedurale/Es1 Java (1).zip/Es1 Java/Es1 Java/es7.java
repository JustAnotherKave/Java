//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
/*In un condominio è stato messo a norma l’ascensore, l’ammontare che deve
pagare ciascun condomino dipende anche dal piano nel quale si trova
l’appartamento. Tale ammontare viene determinato nel seguente modo:
a. Quota base : una cifra fissa
b. la quota base viene incrementata in base al piano al quale si trova
l’appartamento secondo la seguente tabella
N° PIANO COMMISSIONE
Piano terra 0%
1 1.25%
2 1.55%
3 1.9%
4 2.20%
5 2.35%
Data la quota base e il numero del piano di appartenenza comunicare il totale
dovuto da un condomino*/
import java.util.Scanner;
public class Main {
    static Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        int piano;
        double quotafissa=100.0;
        double totale;
        System.out.println("La cifra fissa iniziale da pagare per il condominio è" + quotafissa + "inserire il piano a cui si appartiene");
        piano=scanner.nextInt();
        do{
            if(piano==0){
                totale=quotafissa+(quotafissa*0);
                System.out.println("Cifra da pagare:"+totale);
            }
            else if(piano==1){
                totale= (quotafissa+(quotafissa*0.0125));
                System.out.println("Cifra da pagare:"+totale);
            }
            else if(piano==2){
                totale= (quotafissa+(quotafissa*0.0155));
                System.out.println("Cifra da pagare:"+totale);
            }
            else if(piano==3){
                totale= (quotafissa+(quotafissa*0.0190));
                System.out.println("Cifra da pagare:"+totale);
            }
            else if(piano==4){
                totale= (quotafissa+(quotafissa*0.0220));
                System.out.println("Cifra da pagare:"+totale);
            }
            else if(piano==5){
                totale= (quotafissa+(quotafissa*0.0235));
                System.out.println("Cifra da pagare:"+totale);
            }


        }while(piano<0 && piano>5);


    }
}