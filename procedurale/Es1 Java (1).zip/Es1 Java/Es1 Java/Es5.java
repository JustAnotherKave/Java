/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es5;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class Es5 {

    /**
     * @param args the command line arguments
     */
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
          
        System.out.println("Scegli un voto e io ti dirò se è sufficiente o meno");
        int voto=scanner.nextInt();
        
        System.out.println(voto);
        if(voto<1 || voto>10){
            System.out.println("Voto non valido");
        }
        else if(voto<6){
            System.out.println("Insufficente");
        }
        else{
            System.out.println("Sufficente");
        }
        // TODO code application logic here
    }
    
}