/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package esercitazione1;

public class Esercitazione1 {


    public static void main(String[] args) {
       int Area=15;
       int Altezza=5;
       int base=0;
       int perimetro=0;
       System.out.println("Devo calcolare il perimetro di un rettangolo, prima calcoliamo  la base");
       base=Area/Altezza;
       System.out.println(base + " e' la base");
       System.out.println("Ora calcolo il perimetro");
       perimetro= 2*(base+Altezza);
       System.out.println("Il tuo perimetro: "+ perimetro);
       
    }
    
}
