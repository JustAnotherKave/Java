/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es3;

/**
 *
 * @author Studente
 */
public class Es3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int costoAutomobile=27000;
       int numeroMesi=0;
       int costoRata=300;
       System.out.println("L'auto costa 27000 euro, l'utente versa prima 5000 euro e poi 10000. poi paga ogni mese una rata di 300€, calcola quanti mesi servono per saldare il conto");
       costoAutomobile-=15000;
       System.out.println("Il costo attuale è: "+costoAutomobile);
       
       numeroMesi=costoAutomobile/costoRata;
       System.out.println("il numero  dei mesi è: " + numeroMesi);
    }
    
}
