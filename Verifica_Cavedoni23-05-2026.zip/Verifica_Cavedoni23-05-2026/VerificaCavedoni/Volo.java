public class Volo extends Aereoporto {


    private String aereoportoFinale;
    private String aereo;
    private Passeggero[] elencoP;
    private String cittaFinale;
    private int cont;

    //costruttore con il costruttore passato dalla classe Aereoporto
    public Volo(String citta, String nome, String sigla, String aereo, String aereoportoFinale, String cittaFinale) {
        super(citta, nome, sigla);
        this.aereo = aereo;
        this.aereoportoFinale = aereoportoFinale;
        this.cittaFinale=cittaFinale;
        elencoP=new Passeggero[2];//creo l'array
    }

    //inizio getter e setter
    public String getAereo() {
        return aereo;
    }

    public void setAereo(String aereo) {
        this.aereo = aereo;
    }

    public String getAereoportoFinale() {
        return aereoportoFinale;
    }

    public void setAereoportoFinale(String aereoportoFinale) {
        this.aereoportoFinale = aereoportoFinale;
    }

    public String getCittaFinale() {
        return cittaFinale;
    }

    public void setCittaFinale(String cittaFinale) {
        this.cittaFinale = cittaFinale;
    }

    public Passeggero[] getElencoP() {
        return elencoP;
    }

    public void setElencoP(Passeggero[] elencoP) {
        this.elencoP = elencoP;
    }
    //fine getter e setter

    //aggiungo un oggetto di tipo passeggero nell'array di oggetti
    public void aggiungiP(Passeggero P){
        if(cont<elencoP.length){
            elencoP[cont]=P;
            cont++;
        }

    }
    //stampa le informazioni
    public String Stampa(){
        return "Sigla:"+getSigla()+"\n Città:"+getCitta()+"\nNome Aereoporto di parteza:"+getNome()+"\n Nome aereoporto di arrivo:"+aereoportoFinale;
    }

    //stampa i passeggeri presenti nell'array
    public void StampaPasseggeri(){
        for(int i=0;i<elencoP.length;i++){
            System.out.println("Nome passeggero"+(i)+":"+elencoP[i].getNome()+"\n");
        }

    }
    //stampa i posti di chi ha il menù vegetariano
    public void StampaVegetariani(){
        for(int i=0;i<elencoP.length;i++){
            if(elencoP[i].getTipoPasto().equals("Vegetariano")||elencoP[i].getTipoPasto().equals("vegetariano")){
                System.out.println(elencoP[i].getPostoAssegnato());
            }
        }
    }


}
