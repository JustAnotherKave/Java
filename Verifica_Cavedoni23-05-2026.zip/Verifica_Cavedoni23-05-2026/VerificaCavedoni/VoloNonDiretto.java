public class VoloNonDiretto extends Volo{
    private Aereoporto[] Scali;//Array di oggetti dove sono presenti gli scali
    private int cont;//contatore per inserire gli oggetti di tipo Aereoporto

    //costruttore con anche il costruttore passato dalla classe volo
    public VoloNonDiretto(String citta,String cittaFinale, String nome, String sigla, String aereo, String aereoportoFinale) {
        super(citta,cittaFinale, nome, sigla, aereo, aereoportoFinale);
        Scali=new Aereoporto[2];
    }
//inizio getter e seetter
    public Aereoporto[] getScali() {
        return Scali;
    }

    public void setScali(Aereoporto[] scali) {
        Scali = scali;
    }
    //finge getter e setter

    //aggiungo gli oggetti all'array passandogli l'oggetto e incrementando il cont per tenermi la posizione salvata
    public void AggiungiScali(Aereoporto p1){
        if(cont<Scali.length){
            Scali[cont]=p1;
            cont++;
        }

    }

    //stampo tutte le informazioni con gli scali
    public void StampaConScali(){
        System.out.println(getSigla()+","+getCitta()+","+getNome()+" - "+getAereoportoFinale()+","+getCittaFinale());
        for(int i=0;i< Scali.length;i++){
            System.out.println("Scali:"+Scali[i].getCitta()+","+Scali[i].getNome());
        }
    }

}
