public class Aereoporto {
    private String nome;//nome dell'areoporto
    private String citta;
    private String sigla;

    //costruttore
    public Aereoporto(String citta, String nome, String sigla ) {
        this.citta = citta;
        this.nome = nome;
        this.sigla = sigla;

    }
    //inizio getter e setter
    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }
    //fine getter e setter
}
