public class Passeggero {

    private String nome;
    private String nazionalita;
    private String siglaVolo;
    private String postoAssegnato;
    private String tipoPasto;

    //costruttore parametrico
    public Passeggero(String nazionalita, String nome, String postoAssegnato, String siglaVolo, String tipoPasto) {
        this.nazionalita = nazionalita;
        this.nome = nome;
        this.postoAssegnato = postoAssegnato;
        this.siglaVolo = siglaVolo;
        this.tipoPasto = tipoPasto;
    }
    //inizio getter e setter
    public String getNazionalita() {
        return nazionalita;
    }

    public void setNazionalita(String nazionalita) {
        this.nazionalita = nazionalita;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPostoAssegnato() {
        return postoAssegnato;
    }

    public void setPostoAssegnato(String postoAssegnato) {
        this.postoAssegnato = postoAssegnato;
    }

    public String getSiglaVolo() {
        return siglaVolo;
    }

    public void setSiglaVolo(String siglaVolo) {
        this.siglaVolo = siglaVolo;
    }

    public String getTipoPasto() {
        return tipoPasto;
    }

    public void setTipoPasto(String tipoPasto) {
        this.tipoPasto = tipoPasto;
    }
    //fine getter e setter
    //permette all'oggetto di cambiare un suo attributo, ovvero il posto assegnato
    public void CamiaPosto(String posto){
        postoAssegnato=posto;
    }

}
