public class Main {
    public static void main(String[] args){
        //creo 3 oggetti della classe aereoporto
        Aereoporto a1=new Aereoporto("Bologna","AereoportoBo","Bo");
        Aereoporto a2=new Aereoporto("Bagdad","BagdadAir","BGA");
        Aereoporto a3=new Aereoporto("sudan","SUDanAir","SDNA");
        //creo 2 oggetti di tipo passeggeri
        Passeggero p1=new Passeggero("Francese","Verso","15F","Z453","Vegetariano");
        Passeggero p2=new Passeggero("Romano","Totti","12F","Z453","Carbonara");

        //creo un oggetto di tipo Volo e uno di tipo VoloNonDiretto
        Volo v1=new Volo("Roma","DajeRomanaccia","DROMA","Boing747","GiapeneseAirline","Giappone");
        VoloNonDiretto v2=new VoloNonDiretto("Madrid","Cina","MAdridAir","F34fha","FAAAA4","CinaAirline");

        //aggiungo all'array di v1 gli oggetti passeggeri
        v1.aggiungiP(p1);
        v1.aggiungiP(p2);

        //Stampa le info del oggetto v1
        System.out.println("Stampo info");
        v1.Stampa();
        //stampa i nomi dei passeggeri
        System.out.println("Stampo i nomi dei passeggeri");
        v1.StampaPasseggeri();

        //stampa chi è vegetariano
        System.out.println("Stampo chi ha oridnato il menù vegetariano");
        v1.StampaVegetariani();
        //invoco il metodo che permette al oggetto p1 di cambiare posto
        p1.CamiaPosto("19A");
        //riuso questo metodo, sapendo che p1 è vegetariano, potrò avere la conferma che il metodo precedente funzioni
        v1.StampaVegetariani();

        //aggiungo uno scalo
        v2.AggiungiScali(a2);
        v2.AggiungiScali(a3);

        //aggiungo gli oggetti passeggeri al volo v2
        v2.aggiungiP(p1);
        v2.aggiungiP(p2);

        //Stampo prima i nomi dei passeggeri poi il posto di chi è vegetariano
        v2.StampaPasseggeri();
        v2.StampaVegetariani();

        //stampo tutte le info con gli scali
        v2.StampaConScali();


    }
}
