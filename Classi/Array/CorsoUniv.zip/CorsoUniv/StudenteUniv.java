import java.time.LocalDate;

public class StudenteUniv {
    private String Nome;
    private String Cognome;
    private int Matricola;
    private int Birth;
    private String Provincia;

    public StudenteUniv(String Nome, String Cognome, int Matricola, int Birth, String Provincia){
        this.Nome=Nome;
        this.Cognome=Cognome;
        this.Matricola=Matricola;
        this.Birth=Birth;
        this.Provincia=Provincia;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String Cognome) {
        this.Cognome = Cognome;
    }

    public int getMatricola() {
        return Matricola;
    }

    public void setMatricola(int Matricola) {
        this.Matricola = Matricola;
    }

    public int getBirth() {
        return Birth;
    }

    public void setBirth(int Birth) {
        this.Birth = Birth;
    }

    public String getProvincia() {
        return Provincia;
    }

    public void setProvincia(String Provincia) {
        this.Provincia = Provincia;
    }

    public int Età(){
        int AnnoAttuale=LocalDate.now().getYear();
        int eta=AnnoAttuale-this.Birth;
        return eta;
    }



}
