//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        StudenteUniv s1=new StudenteUniv("Lorenzo","Cavedoni",00,2008,"Ferrara");
        StudenteUniv s2=new StudenteUniv("Jacopo","Gaetani",01,2009,"Lecce");
        StudenteUniv s3=new StudenteUniv("Abd","Nekkaa",02,2009,"Bologna");
        StudenteUniv s4=new StudenteUniv("Fuku","Shima",03,2007,"Filippine");
        StudenteUniv s5=new StudenteUniv("Basilico","Gotico",04,2010,"Bologna");
        StudenteUniv s6=new StudenteUniv("Para","Ion",05,2008,"Moldavia");

        s1.Età();
        s2.Età();
        s3.Età();
        s4.Età();
        s5.Età();
        s6.Età();



    }
}