public class Corso {
    private String NomeCorso;
    private String NomeDocente;
    private int Crediti;
    private String Settore;
    private StudenteUniv[] NStudente=new StudenteUniv[30];
    private int StudentiIscritti=0;


    public Corso(String NomeCorso, String NomeDocente, int Crediti, String Settore, int StudentiIscritti) {
        this.NomeCorso = NomeCorso;
        this.NomeDocente = NomeDocente;
        this.Crediti = Crediti;
        this.Settore = Settore;
        //this.StudentiIscritti=StudentiIscritti;
    }

    public String getNomeCorso() {
        return NomeCorso;
    }

    public void setNomeCorso(String NomeCorso) {
        this.NomeCorso = NomeCorso;
    }

    public String getNomeDocente() {
        return NomeDocente;
    }

    public void setNomeDocente(String NomeDocente) {
        this.NomeDocente = NomeDocente;
    }

    public int getCrediti() {
        return Crediti;
    }

    public void setCrediti(int Crediti) {
        this.Crediti = Crediti;
    }

    public String getSettore() {
        return Settore;
    }

    public void setSettore(String Settore) {
        this.Settore = Settore;
    }

    public Corso(int StudentiIscritti) {
        this.StudentiIscritti = StudentiIscritti;
    }

    public void AggiungiStudente(StudenteUniv s1){
        if(this.StudentiIscritti<NStudente.length){

            NStudente[StudentiIscritti]=s1;

            this.StudentiIscritti++;

        }
        else{
            System.out.println("no");
        }
    }

    public void StampaMatricola(){
        for(int i=0;i<NStudente.length;i++){
            System.out.println("Numero matricola :"+NStudente[i].getMatricola());
        }
    }

    public void MatricolaSoloSe(int k){
        for(int i=0;i<NStudente.length;i++){
            if(NStudente[i].getMatricola()>k){
                System.out.println("Numero matricola superiore a:"+k+":"+NStudente[i].getMatricola());
            }
        }
    }
    /*un metodo che, date due stringhe che denotano un nome ed un cognome,
restituisce true se nell’elenco degli studenti del corso compare uno studente con
nome e cognome dati, altrimenti il metodo restituisce false.*/
    public boolean Stringhette(String N, String C){
        for (int i =0;i<NStudente.length;i++){
            if(N==NStudente[i].getNome() && C==NStudente[i].getCognome()){
                return true;
            }
            else{
                return false;
            }
        }
        return false;
    }

}
