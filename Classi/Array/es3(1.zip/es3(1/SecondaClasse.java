public class SecondaClasse {
    /*public static boolean palindromo(int[] array): che verifica se l'array in input
     è palindromo (ovvero se non cambia ad essere letto dalla prima cella all’ultima o viceversa)*/

   /* public static boolean palindromo(int[] a) {
        int[] b = new int[5];

        int j = 4;
        for (int i = 0; i < a.length; i++) {


        }
    }*/


    public static void StampaNonRipetuti(int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] != a[i + 1]) {
                System.out.println(a[i]);

            }
        }
    }

    public static void crivello(int n){
        for(int i=1;i<=n;i++){
            System.out.println(i);
            System.out.println("ora senza i multipli di 2");
            if(i%2!=0 || i==2){
                System.out.println(i);
            }
            if(i%3!=0 || i==3){

                System.out.println(i);
            }
            if( i % 5!=0 || i==5){
                System.out.println(i);

            }
        }

    }

}

