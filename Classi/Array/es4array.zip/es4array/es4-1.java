//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import java.util.Scanner;
public class Main {
    static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args) {
        int[][] a;
        a=new int[3][3];
        int somma=0;

        for (int i = 0; i < a.length; i++) {
            for(int j=0;j<a.length; j++){
               a[i][j]=scanner.nextInt();
            }
        }
        for (int i = 0; i < a.length; i++) {
            for(int j=0;j<a.length; j++){
                somma+=a[i][j];
            }
        }
        System.out.println(somma);
    }
}