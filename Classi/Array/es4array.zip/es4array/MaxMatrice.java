public class MaxMatrice {
    public static void main(String[] args){
        int[][] matrice = {
                {3, 7, 2},
                {9, 1, 5}
        };

        int max = matrice[0][0];
        int rigaMax = 0;
        int colonnaMax = 0;

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                if (matrice[i][j] > max) {
                    max = matrice[i][j];
                    rigaMax = i;
                    colonnaMax = j;
                }
            }
        }

        System.out.println("Valore massimo: " + max);
        System.out.println("Posizione: riga " + rigaMax + ", colonna " + colonnaMax);


    }
}
