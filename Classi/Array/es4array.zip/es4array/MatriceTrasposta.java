public class MatriceTrasposta {
    public static void main(String[] args){
        int[][] matrice = {
                {1, 2, 3},
                {4, 5, 6}
        };

        System.out.println("Matrice originale:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(matrice[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println("\nMatrice trasposta:");

        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 2; i++) {
                System.out.print(matrice[i][j] + " ");
            }
            System.out.println();
        }
    }
}
