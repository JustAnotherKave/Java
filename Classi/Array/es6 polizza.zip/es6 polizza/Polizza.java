public class Polizza {

    private String Targa;
    private String Intestatario;
    private int premio;
    private int ValoreAssicurativo;

    public Polizza(String Targa, String Intestatario, int premio, int ValoreAssicurativo) {
        this.Targa = Targa;
        this.Intestatario = Intestatario;
        this.premio = premio;
        this.ValoreAssicurativo = ValoreAssicurativo;
    }

    public String getTarga() {
        return Targa;
    }

    public void setTarga(String Targa) {
        this.Targa = Targa;
    }

    public String getIntestatario() {
        return Intestatario;
    }

    public void setIntestatario(String Intestatario) {
        this.Intestatario = Intestatario;
    }

    public int getPremio() {
        return premio;
    }

    public void setPremio(int premio) {
        this.premio = premio;
    }

    public int getValoreAssicurativo() {
        return ValoreAssicurativo;
    }

    public void setValoreAssicurativo(int ValoreAssicurativo) {
        this.ValoreAssicurativo = ValoreAssicurativo;
    }


    public String StampaPolizza(){
       return "La polizza, del signor:"+Intestatario+" è: "+premio+", del veicolo:"+Targa+", con valore assicurativo:"+ValoreAssicurativo;

    }

    public void ApplicaSconto(){
        this.premio-=(premio*20)/100;

    }
    public void Aumenta(){
        this.premio+=(premio*20)/100;
    }

    public void ValoreRcAlto(){
        if(ValoreAssicurativo<2000){
            System.out.println("Il tuo valore assicurativo è nella media");
        }
        else{
            System.out.println("Hai il valore di assicurazione alto");
        }
    }

    public void EqualsTarga(Polizza p2){
        if(this.Targa.equals(p2.Targa)){
            System.out.println("Le 2 targhe sono uguali");
        }
        else{
            System.out.println("non sono uguali");
        }
    }
    public void BreveDesc(){
        System.out.println("intenstatario:"+Intestatario+", targa:"+Targa);
    }

}
