public class Main {

    public static void main(String[] args){

        Agenzia a1= new Agenzia("ConcessoIlRecesso" ,5);
        Polizza p1=new Polizza("XC12365H","Mario Rossi",500, 1000);
        Polizza p2=new Polizza("HG54365L", "Giacomo Basso",345,1500);
        Polizza p3= new Polizza("TR34987L", "Jacopo Fukushù",590, 900);

        //Mi piace la rossa della 5BI
        a1.AggiungiPolizza(p1);
        a1.AggiungiPolizza(p2);
        a1.AggiungiPolizza(p3);

        a1.stampa();
        a1.SommaPremi();
        a1.PremioMedio();

        a1.CercaPolizza("XC12365H");

        a1.ScontoATutte();

    }
}
