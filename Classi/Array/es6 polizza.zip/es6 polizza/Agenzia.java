public class Agenzia {
    private String Name;
    private Polizza[] Polizze;
    private int NMassimo;
    private int cont=0;
    //costruttore
    public Agenzia(String Name,  int NMassimo) {
        this.Name = Name;
        this.Polizze =  new Polizza[NMassimo];

    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Polizza[] getPolizze() {
        return Polizze;
    }

    public void setPolizze(Polizza[] Polizze) {
        this.Polizze = Polizze;
    }

    public int getNMassimo() {
        return NMassimo;
    }

    public void setNMassimo(int NMassimo) {
        this.NMassimo = NMassimo;
    }

    public void AggiungiPolizza( Polizza p1){

        if(cont<NMassimo){

            Polizze[cont]=p1;
            cont++;
        }
        else{
            System.out.println("troppe polizze registrate");
        }
    }

    public void SommaPremi(){
        int somma=0;
        for(int i=0;i<NMassimo;i++){
            somma+=Polizze[i].getPremio();
        }
        System.out.println("La somma dei premi è:"+somma);
    }

    public void ElencoRc(){
        for(int i=0;i<NMassimo;i++){
            System.out.println(Polizze[i].getValoreAssicurativo());
        }
    }
    public Polizza CercaPolizza(String Targa){
        for(int i=0;i<NMassimo;i++){
            if(Targa.equals(Polizze[i].getTarga())){
                System.out.println("La targa esiste nell'array!");
                return Polizze[i];
            }

        }
        return null;
    }
    public void PremioMedio(){
        int somma=0;
        int media=0;

        for(int i=0;i<NMassimo;i++){
            somma+=Polizze[i].getPremio();
        }
        media=somma/NMassimo;
    }

    public Polizza PremioMax(){
        int max=Polizze[0].getPremio();
        for(int i=0;i<NMassimo;i++){
            if(Polizze[i].getPremio()>=max){
                max=Polizze[i].getPremio();
                return Polizze[i];
            }

        }
        return null;

    }

    public void ContaPolizzeAlte(int soglia){
        int cont=0;
        for(int i=0;i<NMassimo;i++){
            if(Polizze[i].getValoreAssicurativo()>soglia){
                cont++;
            }

        }
    }

    public void ScontoATutte(){
        for(int i=0;i<NMassimo;i++){
            Polizze[i].ApplicaSconto();
        }
    }
    public void stampa(){
        for(int i=0;i<NMassimo;i++){
            System.out.println(Polizze[i].StampaPolizza());
        }
    }
}
