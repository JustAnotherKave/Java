public class Main {
    public static void main(String[] args){

        Studente s1=new Studente("Matteo","Veronesi",2007,10);
        Studente s2=new Studente("Lorenzo","Cavedoni",2008,8);
        Studente s3=new Studente("Fernando", "Giacomini", 1995, 5);
        s1.Stampa();
        s2.Stampa();
        s3.Stampa();
        int eta=0;
        s1.IsMaggiorenne(eta);
        s2.IsMaggiorenne(eta);
        s3.IsMaggiorenne(eta);

        Studente.Migliore(s1, s2);

        Studente.ContStudenti();
        Studente.getMediaGenerale();
    }
}
