/*Realizza una classe Studente con le seguenti caratteristiche.
● nome
● cognome
● anno_nascita
● mediaVoti
● numeroStudenti: contatore di tutti gli studenti
● mediaGenerale: media globale di tutti gli studenti
Il costruttore deve:
● inizializzare tutti gli attributi non statici
● incrementare numeroStudenti
● aggiornare mediaGenerale
Metodi NON statici
1. stampaDati(): stampa tutte le informazioni dello studente
2. aggiornaMedia(double nuovaMedia): aggiorna la media dello studente
3. trovaEta(): trova l’età dello studente a partire dall’anno di nascita e l’anno corrente
4. isMaggiorenne(): restituisce true se lo studente ha almeno 18 anni
Metodi STATICI
1. stampaNumeroStudenti(): stampa il numero totale di studenti
2. getMediaGenerale(): restituisce la media generale
3. studenteMigliore(Studente s1, Studente s2): restituisce lo studente con la media più alta
Classe Main
Nel main:
1. Crea almeno 3 studenti con dati diversi
2. Stampa i dati di ogni studente
3. Verifica se uno studente è maggiorenne
4. Confronta due studenti usando il metodo statico
5. Stampa: numero totale studenti e la media generale*/

import java.time.LocalDate;

public class Studente {

    private String Nome;
    private String Cognome;
    private int Anno_Nascita;
    private double MediaVoti;
    private static int NStudenti=0;
    private static double MediaGenerale;

    public Studente(String Nome, String Cognome, int Anno_Nascita, int MediaVoti){
        this.Nome=Nome;
        this.Cognome=Cognome;
        this.Anno_Nascita=Anno_Nascita;
        this.MediaVoti=MediaVoti;
        NStudenti++;
        MediaGenerale=getMediaGenerale();
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String cognome) {
        Cognome = cognome;
    }

    public int getAnno_Nascita() {
        return Anno_Nascita;
    }

    public void setAnno_Nascita(int anno_Nascita) {
        Anno_Nascita = anno_Nascita;
    }

    public double getMediaVoti() {
        return MediaVoti;
    }

    public void setMediaVoti(int mediaVoti) {
        MediaVoti = mediaVoti;
    }

    public static int getNStudenti() {
        return NStudenti;
    }

    public static void setNStudenti(int NStudenti) {
        Studente.NStudenti = NStudenti;
    }

    public static double getMediaGenerale() {

        return MediaGenerale;
    }

    public static void setMediaGenerale(int mediaGenerale, Studente s1, Studente s2,Studente s3) {

        MediaGenerale = s1.MediaVoti+ s2.MediaVoti+s3.MediaVoti;
    }

    public void Stampa(){
        System.out.println("Nome:"+Nome+"\nCognome:"+Cognome+"\nAnno di nascita:"+Anno_Nascita+"\nMedia:"+MediaVoti);
    }
    //aggiornaMedia(double nuovaMedia): aggiorna la media dello studente

    public void AggiornaMedia(double nuovaMedia){
        MediaVoti=nuovaMedia;

    }

    public void CalcolaEtà(int eta){

        eta= LocalDate.now().getYear()-Anno_Nascita;


    }
    //isMaggiorenne(): restituisce true se lo studente ha almeno 18 anni

    public boolean IsMaggiorenne(int eta){
        this.CalcolaEtà(eta);
        if(eta>18){
            return true;
        }
        else{
            return false;
        }
    }

    public static void ContStudenti(){
        System.out.println("Studenti:"+NStudenti);
    }

    public static void Migliore(Studente s1, Studente s2){
        if(s1.MediaVoti> s2.MediaVoti){
            System.out.println(s1.Nome+" ha la media più alta di :"+s2.Nome);
        }
        else{
            System.out.println(s2.Nome+" ha la media più alta di : "+s1.Nome);
        }
    }

}
