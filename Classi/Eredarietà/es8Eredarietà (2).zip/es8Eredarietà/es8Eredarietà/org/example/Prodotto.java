package org.example;

public class Prodotto {
    private int CodiceBarre;
    private String Desc;
    private double Prezzo;

    public Prodotto(int CodiceBarre, String Desc, double Prezzo) {
        this.CodiceBarre = CodiceBarre;
        this.Desc = Desc;
        this.Prezzo = Prezzo;
    }

    public int getCodiceBarre() {
        return CodiceBarre;
    }

    public void setCodiceBarre(int codiceBarre) {
        CodiceBarre = codiceBarre;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String desc) {
        Desc = desc;
    }

    public double getPrezzo() {
        return Prezzo;
    }

    public void setPrezzo(double prezzo) {
        Prezzo = prezzo;
    }
    public void ApplicaSconto(){
        this.Prezzo-=(Prezzo*5)/100;
    }

    public String Stampa(){
        return Desc+","+Prezzo;
    }
}
