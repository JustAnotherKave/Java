package org.example;

public class LisaSpesa {


    private int dimensione=5;
    private int OggettiInLista;
    private Prodotto[] Lista=new Prodotto[dimensione];
    int  cont=0;

    public LisaSpesa() {
        OggettiInLista=0;
    }

    public int getDimensione() {
        return dimensione;
    }

    public void setDimensione(int dimensione) {
        this.dimensione = dimensione;
    }

    public int getOggettiInLista() {
        return OggettiInLista;
    }

    public void setOggettiInLista(int oggettiInLista) {
        OggettiInLista = oggettiInLista;
    }

    public Prodotto[] getLista() {
        return Lista;
    }

    public void setLista(Prodotto[] lista) {
        Lista = lista;
    }

    public void AggiungiAllaLista(Prodotto p){

        if(cont<Lista.length){
            Lista[cont]=p;
            cont++;
        }

    }

    public void CreaScontrino(){
        for(int i=0;i<Lista.length;i++){
            System.out.println(Lista[i].Stampa());
        }

    }
    public double CalcolaTotale(boolean Scontato){
        double totale=0;
        if(Scontato){
            for (int i=0;i<Lista.length;i++){
                totale+=Lista[i].getPrezzo()-((Lista[i].getPrezzo()*5)/100);
            }


        }
        else{
            for(int i=0;i<Lista.length;i++){
                totale+=Lista[i].getPrezzo();
            }

        }
        System.out.println(totale);
        return totale;
    }

    public String letturaNome(String nomeProdotto){

        for(int i=0;i<Lista.length;i++){
            if(Lista[i].getDesc().equals(nomeProdotto)){
                return Lista[i].getDesc()+","+Lista[i].getPrezzo();
            }
        }
        return "Non c'è il prodotto";

    }


}
