package org.example;

public class Alimentare extends  Prodotto{
    private int GiorniDiCons;

    public Alimentare(int CodiceBarre, String Desc, double Prezzo, int GiorniDiCons) {
        super(CodiceBarre, Desc, Prezzo);
        this.GiorniDiCons = GiorniDiCons;
    }

    public int getGiorniDiCons() {
        return GiorniDiCons;
    }

    public void setGiorniDiCons(int giorniDiCons) {
        GiorniDiCons = giorniDiCons;
    }

    @Override
    public String Stampa() {
        return super.Stampa()+","+GiorniDiCons;
    }

    public void ApplicaSconto(){
        if(GiorniDiCons==4){
            setPrezzo(getPrezzo()*0.90);
            System.out.println("Prezzo Scontato:"+getPrezzo());
        }
        else {
            System.out.println("No prezzo  scontato");
        }
    }

}
