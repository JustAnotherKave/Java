package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class SuperMercato {
    public static void main(String[] args) {

        Prodotto p1=new Prodotto(101110, "Tavolo",50);
        Alimentare p2= new Alimentare(10001,"Petto di Pollo", 8, 5);
        NonAlimentare p3=new NonAlimentare(101101,"Manga",6.5,"Carta");
        Prodotto p4=new Prodotto(100010, "Jacopo peluche", 15);
        Alimentare p5=new Alimentare(111101,"Patatine",5,15);
        LisaSpesa l1=new LisaSpesa();
        l1.AggiungiAllaLista(p1);
        l1.AggiungiAllaLista(p2);
        l1.AggiungiAllaLista(p3);
        l1.AggiungiAllaLista(p4);
        l1.AggiungiAllaLista(p5);
        System.out.println("Inizio scontrino");
        l1.CreaScontrino();
        System.out.println("fine scontrino");
        System.out.println("Cercare un prodotto");

        l1.letturaNome("Manga");
        l1.letturaNome("abd peluche");

        System.out.println("Prezzo totale dei prodotti");
        l1.CalcolaTotale(false);

    }
}