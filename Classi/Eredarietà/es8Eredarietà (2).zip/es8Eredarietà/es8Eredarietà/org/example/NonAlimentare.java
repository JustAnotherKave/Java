package org.example;

public class NonAlimentare extends Prodotto {

    private String  Materiale;

    public NonAlimentare(int CodiceBarre, String Desc, double Prezzo, String Materiale) {
        super(CodiceBarre, Desc, Prezzo);
        this.Materiale = Materiale;
    }

    @Override
    public String Stampa() {
        return super.Stampa()+","+Materiale;
    }

    public void ApplicaSconto(){
        if(Materiale.equals("Plastica")||Materiale.equals("Carta")||Materiale.equals("Vetro")){
            setPrezzo((getPrezzo()*8)/100);
            System.out.println("Prezzo Scontato:"+getPrezzo());
        }
        else{
            System.out.println("No prezzo scontato");
        }
    }
}
