public class Personale {
    private String nome;
    private String cognome;
    private String indirizzo;
    private int telefono;
    private double quota;

    public Personale( String nome, String cognome,String indirizzo, int telefono, double quota) {
        this.indirizzo = indirizzo;
        this.nome = nome;
        this.cognome = cognome;
        this.telefono=telefono;
        this.quota=quota;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public double getQuota() {
        return quota;
    }

    public void setQuota(double quota) {
        this.quota = quota;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void stampaDati(){
        System.out.println(nome+","+cognome+","+indirizzo+","+telefono+","+quota);
    }
    public double paga(){
        return this.getQuota();
    }
}
