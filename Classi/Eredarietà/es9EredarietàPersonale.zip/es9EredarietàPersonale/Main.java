//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // =========================
        // OGGETTI PERSONALE
        // =========================
        Personale p1 = new Personale(
                "Mario",
                "Rossi",
                "Via Roma 10",
                123456789,
                1000
        );

        Personale p2 = new Personale(
                "Luigi",
                "Verdi",
                "Via Milano 20",
                987654321,
                1200
        );

        System.out.println("=== PERSONALE ===");
        p1.stampaDati();
        System.out.println("Paga: " + p1.paga());

        p2.stampaDati();
        System.out.println("Paga: " + p2.paga());



        // =========================
        // OGGETTI VOLONTARIO
        // =========================
        Volontario v1 = new Volontario(
                "Anna",
                "Bianchi",
                "Via Napoli 5",
                111111111,
                500
        );

        Volontario v2 = new Volontario(
                "Luca",
                "Neri",
                "Via Torino 8",
                222222222,
                700
        );

        System.out.println("\n=== VOLONTARI ===");
        v1.stampaDati();
        System.out.println("Paga: " + v1.paga());

        v2.stampaDati();
        System.out.println("Paga: " + v2.paga());



        // =========================
        // OGGETTI DIPENDENTE GIORNALIERO
        // =========================
        DipendenteGiornaliero d1 = new DipendenteGiornaliero(
                "Paolo",
                "Russo",
                "Via Firenze 3",
                333333333,
                50,
                "RSSPLA01A01F205X",
                80
        );

        DipendenteGiornaliero d2 = new DipendenteGiornaliero(
                "Giulia",
                "Ferrari",
                "Via Venezia 15",
                444444444,
                60,
                "FRRGLL02B02F205Y",
                90
        );

        System.out.println("\n=== DIPENDENTI GIORNALIERI ===");

        // test metodo giorni()
        d1.giorni(5);
        d1.stampaDati();
        System.out.println("Paga: " + d1.paga());

        d2.giorni(3);
        d2.stampaDati();
        System.out.println("Paga: " + d2.paga());



        // =========================
        // OGGETTI IMPIEGATO
        // =========================
        Impiegato i1 = new Impiegato(
                "Marco",
                "Conti",
                "Via Genova 12",
                555555555,
                1500,
                300,
                "CNTMRC01C01F205Z",
                2000
        );

        Impiegato i2 = new Impiegato(
                "Sara",
                "Gialli",
                "Via Bologna 18",
                666666666,
                1700,
                250,
                "GLLSRA02D02F205K",
                2200
        );

        System.out.println("\n=== IMPIEGATI ===");

        // test metodo gratifica()
        i1.gratifica(200);
        i1.stampaDati();
        System.out.println("Paga: " + i1.paga());

        i2.gratifica(150);
        i2.stampaDati();
        System.out.println("Paga: " + i2.paga());



        // =========================
        // ARRAY LISTAPERSONALE
        // =========================
        ListaPersonale lista = new ListaPersonale();

        lista.inserisci(p1);
        lista.inserisci(p2);

        lista.inserisci(v1);
        lista.inserisci(v2);

        lista.inserisci(d1);
        lista.inserisci(d2);

        lista.inserisci(i1);
        lista.inserisci(i2);

        System.out.println("\n=== STAMPA ARRAY PERSONALE ===");
        lista.stampaLista();
    }
}

