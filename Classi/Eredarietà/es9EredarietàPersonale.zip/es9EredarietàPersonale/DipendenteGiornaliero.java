public class DipendenteGiornaliero extends Personale{
    private String codFiscale;
    private int paga;
    private int giorniDiLavoro;

    public DipendenteGiornaliero(String nome, String cognome, String indirizzo, int telefono, double quota, String codFiscale, int paga) {
        super(nome, cognome, indirizzo, telefono, quota);
        this.codFiscale = codFiscale;
        this.giorniDiLavoro = 0;
        this.paga=paga;
    }

    public String getCodFiscale() {
        return codFiscale;
    }

    public void setCodFiscale(String codFiscale) {
        this.codFiscale = codFiscale;
    }

    public int getGiorniDiLavoro() {
        return giorniDiLavoro;
    }

    public void setGiorniDiLavoro(int giorniDiLavoro) {
        this.giorniDiLavoro = giorniDiLavoro;
    }

    public void giorni(int n){
        giorniDiLavoro+=n;
    }

    public int getPaga() {
        return paga;
    }

    public void setPaga(int paga) {
        this.paga = paga;
    }

    public void stampaDati() {
        System.out.println(getNome()+","+getCognome()+","+getQuota()+","+getIndirizzo()+","+getTelefono()+","+giorniDiLavoro+","+codFiscale+","+paga);
    }
    public double paga(){


         this.setQuota(getQuota()*giorniDiLavoro);
        setGiorniDiLavoro(0);
        return  getQuota();
    }
}
