public class Volontario extends Personale{

    public Volontario(String nome, String cognome, String indirizzo, int telefono, double quota) {
        super(nome, cognome, indirizzo, telefono, quota);
    }


    public double paga(){
       this.setQuota(0);
        return this.getQuota();
    }

}
