public class ListaPersonale {
    private Personale[] lista;
    private int contatore;

    public ListaPersonale() {
        lista = new Personale[20];
        contatore = 0;
    }

    public void inserisci(Personale p) {
        lista[contatore] = p;
        contatore++;
    }

    public void stampaLista() {
        for (int i = 0; i < contatore; i++) {
            lista[i].stampaDati();
        }
    }
}

