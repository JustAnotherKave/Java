public class Impiegato extends Personale{
    private String codFiscale;
    private double pagaMensile;
    private double bonus;

    public Impiegato(String nome, String cognome, String indirizzo, int telefono, double quota, int bonus, String codFiscale,int pagaMensile) {
        super(nome, cognome, indirizzo, telefono, quota);
        this.bonus = bonus;
        this.codFiscale = codFiscale;
        this.pagaMensile=pagaMensile;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public String getCodFiscale() {
        return codFiscale;
    }

    public void setCodFiscale(String codFiscale) {
        this.codFiscale = codFiscale;
    }



    public double getPagaMensile() {
        return pagaMensile;
    }

    public void setPagaMensile(double pagaMensile) {
        this.pagaMensile = pagaMensile;
    }
    public void gratifica(double x){
        pagaMensile+=x;
    }
    public void stampaDati() {
        System.out.println(getNome()+","+getCognome()+","+getQuota()+","+getIndirizzo()+","+getTelefono()+","+bonus+","+codFiscale+","+pagaMensile);
    }

    public double paga(){


        this.setQuota(getQuota()+bonus);
        setBonus(0);
        return  getQuota();
    }


}
