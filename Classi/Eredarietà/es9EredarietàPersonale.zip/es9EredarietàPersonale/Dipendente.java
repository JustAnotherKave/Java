public class Dipendente {
}
