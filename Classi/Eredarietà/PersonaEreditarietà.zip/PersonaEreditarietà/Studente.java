public class Studente extends Persona{
    public int Matricola;
    public String Corso;
    public int Media;

    public Studente(String Nome, String Cognome, int AnnoDiNascita, String Residenza, String CodiceFiscale, int Matricola, String Corso, int Media) {

        super(Nome, Cognome, AnnoDiNascita, Residenza, CodiceFiscale);
        this.Matricola = Matricola;
        this.Corso = Corso;
        this.Media = Media;
    }

    public void MostraDati(){
        System.out.println("Nome:"+Nome+", Cognome:"+Cognome+",Anno di nascita:"+AnnoDiNascita+", Residenza:"+Residenza+", Codice fiscale:"+CodiceFiscale+", Matricola:"+Matricola+",Corso:"+Corso+",Media:"+Media);
    }

    public boolean promosso(){
        if(Media>18){
            System.out.println(Nome+" promosso");
            return true;
        }
        System.out.println(Nome+" bocciato");
        return false;
    }

    public void aggiornaMedia(int nuovaMedia){
        Media=nuovaMedia;
    }
    public void Presentati(){
        System.out.println("Ciao sono "+Nome+" "+Cognome+" e studio informatica");

    }



}
