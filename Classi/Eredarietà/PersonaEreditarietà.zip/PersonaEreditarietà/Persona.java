import java.time.LocalDate;

public class Persona {
    public String Nome;
    public String Cognome;
    public int AnnoDiNascita;
    public String Residenza;
    public String CodiceFiscale;

    public Persona(String Nome, String Cognome, int AnnoDiNascita, String Residenza, String CodiceFiscale) {
        this.Nome = Nome;
        this.Cognome = Cognome;
        this.AnnoDiNascita = AnnoDiNascita;
        this.Residenza = Residenza;
        this.CodiceFiscale = CodiceFiscale;
    }

    public void Presentati(){
        System.out.println("Nome:"+Nome+", Cognome:"+Cognome+",Anno di nascita:"+AnnoDiNascita+", Residenza:"+Residenza+", Codice fiscale:"+CodiceFiscale);

    }
    public int trovaEta(){
        int annoCorrente=0;
        annoCorrente=LocalDate.now().getYear();
        int eta=annoCorrente-AnnoDiNascita;
        return eta;
    }
    public boolean maggiorenne(){
        if (trovaEta()>=18){
            System.out.println(Nome+" è maggiorenne");
            return true;
        }
        return false;
    }
}
