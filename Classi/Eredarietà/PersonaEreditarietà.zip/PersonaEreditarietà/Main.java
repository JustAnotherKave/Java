public class Main {

    public static void main(String[] args){
    Persona p1= new Persona("Lorenzo","RossaPrimavera",2008,"Ferrara","CVNLRZ30A15");
    Persona p2= new Persona("Jacopo","Fukushu",2009,"Lecce","JCP24AR3");
    Persona p3=new Persona("Abd","Nekkaa",2012,"Barca","BD34FEB2");

    Studente p4= new Studente("Marco","Parini",2008,"Australia","MRCPRN3A123",15343, "Informatica", 18);
    Studente p5= new Studente("Matteo","Veronesi",2007,"Bologna","MTTVRN3A163",14565, "Informatica", 30);

    Professori p6= new Professori("Valerio","Gambetti",1978,"Bologna","VLRGMB34325", "Informatica-Sistemi",15);

    p1.Presentati();
    p2.Presentati();
    p3.Presentati();
    p4.Presentati();
    p5.Presentati();

    p4.MostraDati();
    p5.MostraDati();

    System.out.println(p1.trovaEta());
    System.out.println(p2.trovaEta());
    System.out.println(p3.trovaEta());
    System.out.println(p4.trovaEta());
    System.out.println(p5.trovaEta());

    System.out.println("controllare chi è maggiorenne");

    p1.maggiorenne();
    p2.maggiorenne();
    p3.maggiorenne();
    p4.maggiorenne();
    p5.maggiorenne();

    p4.promosso();
    p5.promosso();

    p4.aggiornaMedia(20);
    p5.aggiornaMedia(32);

    p6.esperto();
    p6.Presentati();

    }
}
