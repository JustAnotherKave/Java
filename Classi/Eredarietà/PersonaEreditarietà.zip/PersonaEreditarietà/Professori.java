public class Professori extends Persona {
    public String Materia;
    public int Anni;

    public Professori(String Nome, String Cognome, int AnnoDiNascita, String Residenza, String CodiceFiscale, String materia, int anni) {

        super(Nome, Cognome, AnnoDiNascita, Residenza, CodiceFiscale);
        Materia = materia;
        Anni = anni;
    }
    public boolean esperto(){
        if(Anni>10){
            System.out.println(Cognome+" è esperto");
            return true;
        }
        System.out.println(Cognome+"non è esperto");
        return false;
    }
    public void Presentati(){
        System.out.println("Ciao, sono:"+Nome+" "+Cognome+", e sono prof di:"+Materia);
    }

}
