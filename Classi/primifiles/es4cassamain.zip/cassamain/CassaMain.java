/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cassamain;
import java.util.Scanner;
/**
 *
 * @author Studente
 */
public class CassaMain {

    static Scanner scanner = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int Incasso;
        int scelta;
        ClasseCassa Cassa=new ClasseCassa(15 , 15, 2);
        System.out.println("Ciao vuoi acquistare in questo negozio delle caramelle?(1=si else no");
        scelta= scanner.nextInt();
        if(scelta==1){
            Incasso=15;
            Cassa.Acquistato(Incasso);
        }
        else{
            System.out.println("Pensi di andartene senza comprare nulla? Nein. Compri del caviale.");
            Incasso=400;
            Cassa.Acquistato(Incasso);
        }
        System.out.println("tempo di chiudere baracca");
        System.out.println(Cassa.ComunicaDati());
        
        Cassa.ChiusuraCassa();
        System.out.println("New day new money");
        System.out.println("Ciao vuoi acquistare in questo negozio delle caramelle?(1=si else no");
        scelta= scanner.nextInt();
        if(scelta==1){
            Incasso=15;
            Cassa.Acquistato(Incasso);
        }
        else{
            System.out.println("Pensi di andartene senza comprare nulla? Nein. Compri del caviale.");
            Incasso=400;
            Cassa.Acquistato(Incasso);
        }
        System.out.println("tempo di chiudere baracca");
        System.out.println(Cassa.ComunicaDati());
        
        Cassa.ChiusuraCassa();
    }
    
}
