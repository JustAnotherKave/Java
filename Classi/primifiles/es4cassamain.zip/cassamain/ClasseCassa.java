/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cassamain;

/**
 *
 * @author Studente
 */
public class ClasseCassa {
    
    
    public int DenaroInCassa;
    public int NumeriAcquisti;
    public int FondoCassa;
    
    
    public ClasseCassa(int DenaroInCassa, int NumeriAcquisti, int FondoCassa){
        
        this.DenaroInCassa=DenaroInCassa;
        this.FondoCassa=FondoCassa;
        this.NumeriAcquisti=NumeriAcquisti;
        
    }
    
    public int Acquistato(int Incasso){
        
        NumeriAcquisti++;
        
        DenaroInCassa+=Incasso;
        return DenaroInCassa;
    }
    
    public String ComunicaDati(){
        
        return "Informazioni: Denaro in Cassa:"+DenaroInCassa+" , Numero Acquisti:"+NumeriAcquisti;
        
    }
    
    public void ChiusuraCassa(){
        
        DenaroInCassa=FondoCassa;
        NumeriAcquisti=0;
    }
    
    
    
    
}
