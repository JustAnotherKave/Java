public class Volo {
    String compagnia;
    String codiceVolo;
    String destinazione;
    int oraPartenza;
    int postiTotali;
    int postiPrenotati;
    double prezzoBiglietto;

    // Costruttore completo
    public Volo(String compagnia, String codiceVolo, String destinazione,
                int oraPartenza, int postiTotali, double prezzoBiglietto) {

        this.compagnia = compagnia;
        this.codiceVolo = codiceVolo;
        this.destinazione = destinazione;
        this.oraPartenza = oraPartenza;
        this.postiTotali = postiTotali;
        this.prezzoBiglietto = prezzoBiglietto;
        this.postiPrenotati = 0;
    }

    // Costruttore parziale (usa this)
    public Volo(String codiceVolo, String destinazione,
                int postiTotali, double prezzoBiglietto) {

        this("DefaultAir", codiceVolo, destinazione, 0, postiTotali, prezzoBiglietto);
    }

    // Costruttore vuoto
    public Volo() {
        this("Nessuna", "XXX000", "Sconosciuta", 0, 0, 0);
    }

    // Metodi aggiornamento
    public void aggiornaCompagnia(String c) {
        compagnia = c;
    }

    public void aggiornaCodiceVolo(String codice) {
        codiceVolo = codice;
    }

    public void aggiornaDestinazione(String dest) {
        destinazione = dest;
    }

    public void aggiornaOraPartenza(int ora) {
        if (ora >= 0 && ora <= 23) {
            oraPartenza = ora;
        }
    }

    // Prenotazione
    public boolean verificaPrenotazione(int n) {
        return n > 0 && (postiPrenotati + n) <= postiTotali;
    }

    public void prenotaPosti(int n) {
        if (verificaPrenotazione(n)) {
            postiPrenotati += n;
            System.out.println("Venduti: " + postiPrenotati);
            System.out.println("Disponibili: " + (postiTotali - postiPrenotati));
        } else {
            System.out.println("Prenotazione NON valida!");
        }
    }

    public boolean voloCompleto() {
        return postiPrenotati == postiTotali;
    }

    public double calcolaSpesa() {
        return postiPrenotati * prezzoBiglietto;
    }

    public void stampaBigliettoVolo() {
        System.out.println("----- VOLO -----");
        System.out.println("Compagnia: " + compagnia);
        System.out.println("Codice: " + codiceVolo);
        System.out.println("Destinazione: " + destinazione);
        System.out.println("Ora: " + oraPartenza);
        System.out.println("Posti totali: " + postiTotali);
        System.out.println("Prenotati: " + postiPrenotati);
        System.out.println("Prezzo: " + prezzoBiglietto);
        System.out.println("Incasso: " + calcolaSpesa());
        System.out.println("----------------");
    }

    public void applicaSconto() {
        if (postiPrenotati < (postiTotali / 2)) {
            prezzoBiglietto *= 0.8; // sconto 20%
        }
    }

    public void annullaPrenotazione(int n) {
        if (n > 0) {
            postiPrenotati -= n;
            if (postiPrenotati < 0) {
                postiPrenotati = 0;
            }
        }
    }

    public boolean stessoPrezzo(Volo v) {
        return this.prezzoBiglietto == v.prezzoBiglietto;
    }

    public static double voloPiuConveniente(Volo v1, Volo v2) {
        return Math.min(v1.calcolaSpesa(), v2.calcolaSpesa());
    }
}
