//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // Creazione voli
        Volo v1 = new Volo("ITA", "AZ123", "Roma", 10, 100, 50);
        Volo v2 = new Volo("FR456", "Milano", 80, 30);
        Volo v3 = new Volo();

        // Aggiornamenti
        v2.aggiornaCompagnia("Ryanair");
        v2.aggiornaOraPartenza(15);

        v3.aggiornaCompagnia("EasyJet");
        v3.aggiornaCodiceVolo("EJ789");
        v3.aggiornaDestinazione("Napoli");
        v3.aggiornaOraPartenza(20);

        // Stampa iniziale
        v1.stampaBigliettoVolo();
        v2.stampaBigliettoVolo();
        v3.stampaBigliettoVolo();

        // Prenotazioni
        v1.prenotaPosti(30);
        v1.prenotaPosti(80); // errore

        if (v1.voloCompleto()) {
            System.out.println("TUTTO ESAURITO");
        }

        // Sconto
        v2.prenotaPosti(10);
        v2.applicaSconto();
        v2.stampaBigliettoVolo();

        // Annulla prenotazione
        v2.annullaPrenotazione(5);
        v2.stampaBigliettoVolo();

        // Confronti
        System.out.println("Stesso prezzo? " + v1.stessoPrezzo(v2));

        double min = Volo.voloPiuConveniente(v1, v2);
        System.out.println("Incasso minore: " + min);

        // Stampa finale
        v1.stampaBigliettoVolo();
        v2.stampaBigliettoVolo();
        v3.stampaBigliettoVolo();
    }
}