public class Palestra {
    //attributi della classe palestra
    public String Nome;
    public int NumeroIscritti;
    public int MaxCapacità;
    public boolean Aperta;
    public int Persone;
    //primo costruttore
    public Palestra(String Nome, int MaxCapacità) {

        this(Nome,0,MaxCapacità,false,0);
    }
    //secondo costruttore
    public Palestra(String Nome, int NumeroIscritti, int MaxCapacità, boolean Aperta, int Persone) {
        this.Nome = Nome;
        this.NumeroIscritti = NumeroIscritti;
        this.MaxCapacità=MaxCapacità;
        this.Aperta=Aperta;
        this.Persone=Persone;
    }

    //metodo entra persona
    public void EntraPersona(int Numero){
        if(this.Aperta) {

            // se la palestra è aperta andra in un if se le persone dentro + il numero degli entranti supera MaxCapacità allora non possono entrare
            if (Persone+Numero>=MaxCapacità){
                System.out.println("Non puo entrare");
                Persone+=Numero;
            }
            else {
                System.out.println("Le persone  possono entrare");
                Persone+=Numero;
            }
        }
        //se la palestra è chiusa non si può entrare:[
        else  {
            System.out.println("Non puoi entrare");
        }
    }
    //se c'è almeno una persona dentro, le persone possono uscire
    public void EscePersona(){
        if(Persone>=1){
            System.out.println("La persona sta uscendo dalla palestra");
            Persone--;
        }
        else {
            System.out.println("Nessuno può uscire");
        }

    }
    //chiude la palestra mettendo persone=0
    public void ChiudiPalestra(){
        System.out.println("La palestra sta chiudendo. Tutti sono pregati di uscire");
        Persone=0;
        Aperta=false;
    }
    //setta Aperta=true
    public void ApriPalestra(){

        System.out.println("La palestra sta aprendo!");
        Aperta=true;
    }
    //aggiunge un numero scelto dall'utente d'iscritti
    public void AggiungiIscritto(int numero){
        NumeroIscritti+=numero;
        System.out.println("Iscritto aggiunto. Numero d'iscritti: "+NumeroIscritti);
    }
    //stampa una stringa se la palestra è pieno o meno
    public void PalestraPiena(){
        if(Persone>=MaxCapacità){
            System.out.println("La palestra è piena");

        }
        else{
            System.out.println("La palestra è ancora libera");

        }
    }
    //controlla tra i 2 oggetti chi ha più iscritti, chi meno oppure se sono ugali
    public void ConfrontaIscritti(Palestra p){
        if(this.NumeroIscritti>p.NumeroIscritti){
            System.out.println(this.Nome + " Ha più iscritti di: "+p.Nome);
        }
        else if(this.NumeroIscritti<p.NumeroIscritti){
            System.out.println(p.Nome+" Ha più iscritti di: "+this.Nome);
        }
        else{
            System.out.println("hanno lo stesso numero d'iscritti");
        }
    }
    //controlla tra i 2 oggetti chi ha più capienza, chi meno oppure se sono ugali
    public void ConfrontaCapienza(Palestra p){
        if(this.MaxCapacità>p.MaxCapacità){

            System.out.println(this.Nome+" Ha più capienza di: "+p.Nome);

        }
        else if (this.MaxCapacità<p.MaxCapacità){

            System.out.println(p.Nome+" ha più capienza di: "+this.Nome);
        }
    }
    //stampa le info
    public void StampaInfo(){
        System.out.println("Nome: "+this.Nome + ", Numero iscritti: " + this.NumeroIscritti+" ,MaxCapacità:"+this.MaxCapacità+" ,Aperta:"+this.Aperta+" ,Persone presenti ora:"+this.Persone);
    }
}
