
import java.util.Scanner;


public class Main {
    static Scanner sc = new Scanner(System.in);
   public static void main() {
       int numero;
       Palestra p1= new Palestra("Fitinn", 90, 100,false,0);
       Palestra p2= new Palestra("GimHobbit", 45, 100,false,0);
       CentroSportivo c1= new CentroSportivo("AnzolaVino", 45);

       System.out.println("Sei il responsabile di due palestre guardiamo le statistiche delle palestre e poi è il tempo di aprire le due tue palestre!");
       p1.StampaInfo();
       p2.StampaInfo();

       p1.ApriPalestra();
       p2.ApriPalestra();

       System.out.println("Le persone stanno iniziando ad entrare decidi quante per la palestra 1");
       numero = sc.nextInt();

       p1.EntraPersona(numero);

       System.out.println("Ora per la palestra 2");
       numero = sc.nextInt();
       p2.EntraPersona(numero);
       System.out.println("Che coincidenza, delle persone si stanno iscrivendo allo stesso tempo nella palestra!(una coincidenza eh, non perchè il programmatore è pigro...). Quanti iscritti?");
       numero = sc.nextInt();
       p1.AggiungiIscritto(numero);
       p2.AggiungiIscritto(numero);

       System.out.println("Controlliamo se la palestra è piena o no");
       p1.PalestraPiena();
       p2.PalestraPiena();
       System.out.println("Due persone escono");
       p1.EscePersona();
       p2.EscePersona();
       System.out.println("Ora confrontiamo le due palestre");
       p1.ConfrontaIscritti(p2);
       p1.ConfrontaCapienza(p2);

       System.out.println("Va bene, ora possiamo chiudere la palestra");
       p1.ChiudiPalestra();
       p2.ChiudiPalestra();
       p1.StampaInfo();
       p2.StampaInfo();


       c1.Allenamento(p1, numero);
       c1.Allenamento(p2, numero);
       c1.Allenamento(p1, numero);

    }


}

