public class CentroSportivo {
    public String Nome;
    public int Accessi;

    public CentroSportivo(String Nome, int Accessi){

        this.Nome = Nome;
        this.Accessi = Accessi;
    }
    public void Allenamento(Palestra p, int NPersone){

        p.EntraPersona(NPersone);
        if(p.Aperta && p.Persone<p.MaxCapacità){
            this.Accessi++;
        }
    }
    public void Dati(){
        System.out.println("Nome: "+this.Nome+" Accessi: "+this.Accessi);
    }

}
