package org.example;
import java.util.scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static scanner Scannner= new scanner(System.in);
    static void main(String[] args) {

        Film Film1 = new Film("Pioggia a catinella", 0, true );
        Film Film2 = new Film("Cars2", 3, false );


    }
}
