package org.example;

public class Film {
    public String Titolo;
    public int NVisual;
    public boolean Disponibilità;

    public Film(String Titolo){
        this(Titolo, 0, true);

    }
    public Film( String Titolo, int NVisual, boolean Disponibilità){
        this.Titolo=Titolo;
        this.Disponibilità=Disponibilità;
        this.NVisual=NVisual;
    }

    public void GuardaFilm(){
        if(this.Disponibilità){
            NVisual++;
            System.out.println("Hai noleggiato il film!");
            this.Disponibilità=false;
        }
        else{

            System.out.println("Il film non è disponibile :(");

        }

    }

    public void RendiDisponibile(){
        if (this.Disponibilità) {
            System.out.println("Il film è gia disponibile");
        }
        else{
            this.Disponibilità=true;
            System.out.println("Il film è tornato disponibile");
        }

    }
    public void AggiungiVisual(int numero){
        NVisual+=numero;

    }

    public void PrimaVisione(){
        if (NVisual==0){
            System.out.println("Il film è in prima visione");
        }
        else{
            System.out.println("Il film è in replica");
        }
    }
    public void ConfrontaVisual(Film F){
        if (this.NVisual>F.NVisual){
            System.out.println(this.Titolo+" ha più visualizzazioni di: "+F.Titolo);
        }
        else if(this.NVisual==F.NVisual){
            System.out.println("I due film hanno le stesse visualizzazioni");
        }
        else{
            System.out.println(F.Titolo+ " ha più visualizzazioni di : "+this.Titolo);
        }
    }
    public void Info(){
        System.out.println("Titolo: "+this.Titolo+", N.Visual: "+this.NVisual+" , ed è: "+this.Disponibilità);
    }
}
