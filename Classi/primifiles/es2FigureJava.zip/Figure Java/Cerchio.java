public class Cerchio {

    private double Raggio;
    private String Nome;
    public Cerchio(double Raggio, String Nome){

        this.Raggio=Raggio;
        this.Nome=Nome;

    }

    public String getNome() {
        return Nome;
    }

    public double circonferenza(){

        return 2*Raggio*3.14;
    }

    public double area(){
        return 3.14*(Raggio*Raggio);
    }
    public void Stampa(){

        System.out.println("Nome"+getNome()+" Circonferenza:"+circonferenza()+" , Area:"+area());

    }
}
