//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    Cerchio Cerchio1= new Cerchio(15, "Giovanni");
    Cerchio Cerchio2= new Cerchio(27, "Tony");
    Rettangolo Rettangolo1= new Rettangolo(20, 15,"Pitony");
    Rettangolo Rettangolo2=new Rettangolo(30, 20, "Alfons");
    Triangolo Triangolo1= new Triangolo(10, 10, 5,5,"Galeotto");
    Triangolo Triangolo2= new Triangolo(15,10,5,5,"Gurdulù");
    Quadrato Quadrato1= new Quadrato(10, "Edward Elrich");
    Quadrato Quadrato2= new Quadrato(20, "La capra Neraa");

    Cerchio1.Stampa();
    Cerchio2.Stampa();
    Rettangolo1.Stampa();
    Rettangolo2.Stampa();
    Triangolo1.Stampa();
    Triangolo2.Stampa();
    Quadrato1.Stampa();
    Quadrato2.Stampa();
    }
}