public class Rettangolo {

    private double Base;
    private double Altezza;
    private String Nome;

    public Rettangolo(double Base, double Altezza, String Nome){
        this.Base=Base;
        this.Altezza=Altezza;
        this.Nome=Nome;
    }

    public String getNome() {
        return Nome;
    }


    public double Perimetro(){
        return 2*(Base+Altezza);
    }
    public double Area(){

        return Base*Altezza;
    }
    public void Stampa(){

        System.out.println("Nome"+getNome()+"Perimetro:"+Perimetro()+" , Area:"+Area());

    }
}
