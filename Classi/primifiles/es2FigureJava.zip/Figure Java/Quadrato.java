public class Quadrato {

    private double Lato;
    private String Nome;

    public Quadrato(double Lato,  String Nome){
        this.Lato=Lato;
        this.Nome=Nome;
    }

    public String getNome() {
        return Nome;
    }


    public double Perimetro(){
        return Lato*4;
    }
    public double Area(){

        return Lato*Lato;
    }
    public void Stampa(){

        System.out.println("Nome"+getNome()+"Perimetro:"+Perimetro()+" , Area:"+Area());

    }
}
