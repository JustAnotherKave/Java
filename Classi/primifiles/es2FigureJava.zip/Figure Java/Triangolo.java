public class Triangolo {

    private double Base;
    private double Altezza;
    private double LatoA;
    private double LatoB;
    private String Nome;

    public Triangolo(double Base, double Altezza, double LatoA, double LatoB, String Nome) {

        this.Base=Base;
        this.Altezza=Altezza;
        this.LatoA=LatoA;
        this.LatoB=LatoB;
        this.Nome=Nome;
    }

    public String getNome() {
        return Nome;
    }

    public double Perimetro() {


        return LatoA+LatoB+Base;
    }
    public double Area(){
    return (Base*Altezza)/2;
    }
    public void Stampa(){

        System.out.println("Nome"+getNome()+" Perimetro:"+Perimetro()+" , Area:"+Area());

    }

}
