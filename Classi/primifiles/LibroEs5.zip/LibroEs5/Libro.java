public class Libro {
    public String Titolo;
    public int NumeroPrestiti;
    public boolean Disponibile;

    public Libro(String Titolo){
        this(Titolo,14,true);
    }

    public Libro(String titolo, int numeroPrestiti, boolean disponibile) {
        this.Titolo = Titolo;
        this.NumeroPrestiti = NumeroPrestiti;
        this.Disponibile = Disponibile;
    }

    public void PrestaLibro(){
        if(this.Disponibile){
            System.out.println("Il libro è disponibile!");
            this.NumeroPrestiti++;
            this.Disponibile=false;
        }
        else{
            System.out.println("Il numero è disponibile");
        }
    }
    public void RestituisciLibro(){
        if(this.Disponibile==true){
            System.out.println("Non hai nessun libro da restituire:[");
        }
        else{
            System.out.println("Hai restituito il libro!");
            this.Disponibile=true;
        }

    }
    public void AggingiPrestiti(int NumeroPrestiti){
        this.NumeroPrestiti++;

    }
    public void ConfrontaPrestiti(Libro l2){
        if(this.NumeroPrestiti>l2.NumeroPrestiti){
            System.out.println(this.Titolo+" ha avuto più prestiti di"+l2.Titolo);
        }
        else{
            System.out.println(l2.Titolo+" ha avuto più prestiti di "+this.Titolo);
        }
    }

    public String DammiInfo(){
        if(Disponibile){
            return Titolo+" Ha un numero di prestiti pari a: "+NumeroPrestiti+" ed è disponibile";
        }
        else{
            return Titolo+" Ha un numero di prestiti pari a: "+NumeroPrestiti+" e non è disponibile";
        }

    }

}
