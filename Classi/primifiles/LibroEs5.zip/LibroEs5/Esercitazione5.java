

public class Esercitazione5 {
  public static void main(String[] args){
      int Scelta;
      Libro L1= new Libro("Shattering Souls", 14, true);
      Libro L2=new Libro("l'ottavo Imperatore, FrancescoTotti",10,true);
      System.out.println("benvenuto nella mia libreria, questi sono i libri più venduti nel nostro negozio");
      System.out.println(L1.DammiInfo());
      System.out.println(L2.DammiInfo());
      System.out.println("Il narratore decide che prenderai il primo libro");
      L1.PrestaLibro();
      L1.AggingiPrestiti(L1.NumeroPrestiti);
      System.out.println("Passa un giorno e torni a restituirlo");
      L1.RestituisciLibro();
      System.out.println("Decidi di prendere l'altro");
      L2.PrestaLibro();
      L2.AggingiPrestiti(L2.NumeroPrestiti);
      System.out.println("Passa un giorno e torni a restituirlo");
      L2.RestituisciLibro();

      System.out.println("Il bibleotecaio chiude baracca e confronta i due libri");
      L1.ConfrontaPrestiti(L2);
      System.out.println(L1.DammiInfo());
      System.out.println(L2.DammiInfo());
  }
}