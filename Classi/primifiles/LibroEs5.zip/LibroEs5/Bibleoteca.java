public class Bibleoteca {
    public String NomeBibleteca;
    public int NLibriPrestati;
    public Bibleoteca(String NomeBibleoteca,int NLibriPrestati ){
        this.NLibriPrestati=NLibriPrestati;
        this.NomeBibleteca=NomeBibleoteca;
    }
    public void EffetuaPrestito(Libro libro){
        libro.PrestaLibro();
    }

}
