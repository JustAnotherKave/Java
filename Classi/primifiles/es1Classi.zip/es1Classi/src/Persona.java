import java.time.LocalDate;

public class Persona {
    private String Nome;
    private String Cognome;
    private int AnnoDiNascita;

    public Persona(String Nome, String Cognome, int AnnoDiNascita){
        this.Nome=Nome;
        this.Cognome=Cognome;
        this.AnnoDiNascita=AnnoDiNascita;

    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public int getEta(){
        int AnnoCorrente= LocalDate.now().getYear();
        return AnnoCorrente-AnnoDiNascita;
    }
    /*public int Calcolo(int AnnoCorrente){
        int Anno=0;
        Anno=AnnoCorrente-AnnoDiNascita;
        return Anno;
    }*/

    public String Saluta(){

        return "Ciao, sono "+Nome+" "+Cognome+" e ho: "+getEta()+" anni";
    }

    public String Maggiorenne(){
        if(getEta() >=18){
            return "Sono maggiorenne!";
        }
        return "Non sono maggiorenne";
    }



}
