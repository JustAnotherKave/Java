//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {

        Persona Cave=new Persona("Lorenzo", "Cavedoni",2008);
        Persona Jaco= new Persona("Jacopo","Gaetani",2009);
        Persona Abd=new Persona("Abd","Nekkaa",1978);


        //Metodo saluta
        System.out.println(Cave.Saluta());
        System.out.println(Jaco.Saluta());
        System.out.println(Abd.Saluta());
        
        //Metodo Maggiorenne
        System.out.println(Cave.getNome()+": "+Cave.Maggiorenne());
        System.out.println(Jaco.getNome()+" : "+Jaco.Maggiorenne());
        System.out.println(Abd.getNome()+" : "+Abd.Maggiorenne());




    }
}