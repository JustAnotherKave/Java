import java.sql.SQLOutput;

public class partita {
   public static void main(String[] args){


       Squadra Ferrara =new Squadra("Ferrara", 15,3,0);
       System.out.println("Squadra:"+Ferrara.SquadraNome+" , statistiche:Vinte:"+ Ferrara.PartiteVinte+", Perse: "+Ferrara.PartitePerse+" , Pareggiate:"+Ferrara.Pareggi);
       Ferrara.Aggiorna();
       System.out.println("Punti:"+Ferrara.punti());
       Squadra Bergamo= new Squadra();
       Bergamo.SquadraNome="Bergamo";
       Bergamo.PartiteVinte=7;
       Bergamo.PartitePerse=3;
       Bergamo.Pareggi=4;
       System.out.println("Squadra:"+Bergamo.SquadraNome+", statistiche: Vinte:"+Bergamo.PartiteVinte+" Perse:"+Bergamo.PartitePerse+" Pareggio:"+Bergamo.PartitePerse);
       Bergamo.Aggiorna();
       System.out.println("Punti: "+Bergamo.punti());



       System.out.println("Inizia il nuovo Campionato!");

       Ferrara.NewYear();
       Bergamo.NewYear();

       System.out.println("Squadra:"+Ferrara.SquadraNome+" , statistiche:Vinte:"+ Ferrara.PartiteVinte+", Perse: "+Ferrara.PartitePerse+" , Pareggiate:"+Ferrara.Pareggi+" , Punti:"+Ferrara.punti());
       System.out.println("Squadra:"+Bergamo.SquadraNome+", statistiche: Vinte:"+Bergamo.PartiteVinte+" Perse:"+Bergamo.PartitePerse+" Pareggio:"+Bergamo.PartitePerse+" ,Punti:"+Bergamo.punti());

   }
}
