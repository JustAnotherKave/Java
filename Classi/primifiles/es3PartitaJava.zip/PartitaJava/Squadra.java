public class Squadra {

    public String SquadraNome;
    public int PartiteVinte, PartitePerse,Pareggi, punti=0;

    public Squadra(String SquadraNome, int PartiteVinte, int PartitePerse,int Pareggi){
        this.SquadraNome=SquadraNome;
        this.PartiteVinte=PartiteVinte;
        this.PartitePerse=PartitePerse;
        this.Pareggi=Pareggi;
    }
    public Squadra(){
        SquadraNome="";
        PartiteVinte=0;
        PartitePerse=0;
        Pareggi=0;
    }

    public String punti(){
       return "I punti di "+SquadraNome+" sono:"+punti;
    }
    public int Aggiorna(){
        punti+=(PartiteVinte*3)+(PartitePerse*0)+(Pareggi*1);
        return punti;
    }
    public void NewYear(){
        punti=0;
        PartitePerse=0;
        PartiteVinte=0;
        Pareggi=0;
    }

}
