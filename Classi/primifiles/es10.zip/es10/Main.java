//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Autobuss A= new Autobuss("Bologna centrale - Anzola", 40, 30, 3);
        Autobuss B= new Autobuss();

        A.AggiornaDati("Castelfranco",30,5,5);
        B.AggiornaDati("Ferrara",50,30,15);

        A.Prenotazione(6);
        B.Prenotazione(10);

        A.AnnullaPrenotazione(7);
        B.AnnullaPrenotazione(8);

        A.lastMinute();
        B.lastMinute();

        A.Prenotazione(4);
        B.Prenotazione(3);

        A.Stampa();
        B.Stampa();
    }
}