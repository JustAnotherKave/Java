public class Autobuss {

    private String Destinazione;
    private int PostiMax;
    private int PostiDisponibili;
    private int Tariffa;

    public Autobuss(String Destinazione, int PostiMax, int PostiDisponibili, int Tariffa){
        this.Destinazione=Destinazione;
        this.PostiMax=PostiMax;
        this.PostiDisponibili=PostiDisponibili;
        this.Tariffa=Tariffa;

    }
    public Autobuss(){
        Destinazione="Firenze";
        PostiMax=50;
        PostiDisponibili=38;
        Tariffa=20;
    }

    public String getDestinazione() {
        return Destinazione;
    }

    public void setDestinazione(String destinazione) {
        Destinazione = destinazione;
    }

    public int getPostiMax() {
        return PostiMax;
    }

    public void setPostiMax(int postiMax) {
        PostiMax = postiMax;
    }

    public int getPostiDisponibili() {
        return PostiDisponibili;
    }

    public void setPostiDisponibili(int postiDisponibili) {
        PostiDisponibili = postiDisponibili;
    }

    public int getTariffa() {
        return Tariffa;
    }

    public void setTariffa(int tariffa) {
        Tariffa = tariffa;
    }

    //aggiornaDati() che consente di inserire/modificare i valori degli attributi della classe ViaggioAutobus.
    public void AggiornaDati(String Destinazione, int PostiMax, int PostiDisponbili, int Tariffa){
        this.Destinazione=Destinazione;
        this.PostiMax=PostiMax;
        this.PostiDisponibili=PostiDisponbili;
        this.Tariffa=Tariffa;
    }
    /*prenotazione (), che consente di prenotare i posti per il viaggio,
    naturalmente se ancora disponibili, che decrementa tale numero e comunica la tariffa totale
     da corrispondere e che riceve in ingresso il numero di posti che si intendono prenotare
    (decidere in modo autonomo come trattare il caso di prenotazione non totalmente effettuabile);*/
    public void Prenotazione(int persone){
        if(PostiDisponibili-persone<=0){
            System.out.println("Posti non disponibili");
        }
        else{
            System.out.println("La tariffa è:"+ this.getTariffa());
            this.PostiDisponibili=PostiDisponibili-persone;
            System.out.println("Hai prenotato. I posti disponibili sono:"+this.PostiDisponibili+". La tariffa per un biglietto è:"+this.Tariffa);
        }
    }





    /*annullaPrenotazione(), che prende in ingresso il numero di posti per I
    quali si intende disdire la prenotazione e rende nuovamente disponibili i posti per cui è
    stata effettuata la prenotazione
    e comunica l'importo della tariffa di cui e prevista la restituzione
    * */

    public void AnnullaPrenotazione(int persone){
        if(PostiDisponibili+persone>PostiMax){
            System.out.println("Errore");
        }
        else{
            PostiDisponibili=PostiDisponibili+persone;
            System.out.println("Hai disdetto la prenotazione, restituizione di tutto:"+this.Tariffa*persone);
        }

    }



    /*lastMinute() che modifica la tariffa decrementandone l’importo del 50%.*/
    public void lastMinute(){
        this.Tariffa=Tariffa/2;
    }



    /*comunicaDati() che visualizza lo stato attuale delle prenotazioni, comunicando:
    destinazione viaggio, data viaggio, posti disponibili e tariffa praticata;
    Una volta definita la classe ViaggioAutobus e i suoi metodi compresi i get e i set,
    verificarne il funzionamento nel main costruendo almeno due viaggi in autobus e
    utilizzando tutti i metodi definiti.*/
    public void Stampa(){
        System.out.println(this.Destinazione+","+this.PostiDisponibili+","+this.PostiMax+","+this.Tariffa);
    }

}

