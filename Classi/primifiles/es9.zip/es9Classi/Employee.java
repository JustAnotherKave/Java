import java.time.LocalDate;



public class Employee {
    private String Nome;
    private String Cognome;
    private int Stipendio;
    private int Birthday;
    private String ProfiloProfessionale;
    private int AnniEsperienza;

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String cognome) {
        Cognome = cognome;
    }

    public int getStipendio() {
        return Stipendio;
    }

    public void setStipendio(int stipendio) {
        Stipendio = stipendio;
    }

    public int getBirthday() {
        return Birthday;
    }

    public void setBirthday(int birthday) {
        Birthday = birthday;
    }

    public String getProfiloProfessionale() {
        return ProfiloProfessionale;
    }

    public void setProfiloProfessionale(String profiloProfessionale) {
        ProfiloProfessionale = profiloProfessionale;
    }

    public int getAnniEsperienza() {
        return AnniEsperienza;
    }

    public void setAnniEsperienza(int anniEsperienza) {
        AnniEsperienza = anniEsperienza;
    }

    public Employee(){
        Nome="Mario";
        Cognome="Rossi";
        Stipendio=1300;
        Birthday=1978;
        ProfiloProfessionale="TecnicoInformatico";
        AnniEsperienza=5;
    }
    public Employee(String Nome, String Cognome, int Stipendio, int Birthday, String ProfiloProfessionale, int AnniEsperienza){
        this.Nome=Nome;
        this.Cognome=Cognome;
        this.Stipendio=Stipendio;
        this.Birthday=Birthday;
        this.ProfiloProfessionale=ProfiloProfessionale;
        this.AnniEsperienza=AnniEsperienza;
    }
    public int IncrementaSalario(int perc){
        Stipendio=((Stipendio * 100)/perc);
        return Stipendio;
    }

    public boolean Esperienza(){
        if( this.AnniEsperienza>=10){
            return true;
        }
        else{
            return false;
        }
    }
    public int Confronta(Employee p){
        if(this.Stipendio>p.Stipendio){
            return 1;
        }
        else{
            return 0;
        }
    }
    public int Età(){
        int AnnoCorrente= LocalDate.now().getYear();
        int età;
        età=AnnoCorrente - this.Birthday;
        return età;
    }

    public void Stampa(){
        System.out.println(Nome +" ,"+Cognome+", "+Birthday+", "+Stipendio+", "+AnniEsperienza+" , "+ProfiloProfessionale);
    }

}
