import java.sql.SQLOutput;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Employee p1 = new Employee("Giovanni", "Pitony", 1500, 1999, "Cantante", 9);
        Employee p2= new Employee();
        int perc=30;
        p1.IncrementaSalario(perc);
        p2.IncrementaSalario(perc);
        System.out.println("Salario di:"+p1.getNome()+" "+p1.getCognome()+" è aumento fino a:"+ p1.getStipendio());
        System.out.println("Salario di:"+p2.getNome()+" "+p2.getCognome()+" è aumento fino a:"+ p2.getStipendio());

        if(p1.Esperienza()){
            System.out.println("Il lavoratore ha lavorato per più di 10 anni");
        }
        else{
            System.out.println("falso, non ha lavorato per più di 10 anni");
        }
        if(p2.Esperienza()){
            System.out.println("Il lavoratore ha lavorato per più di 10 anni");
        }
        else{
            System.out.println("falso, non ha lavorato per più di 10 anni");
        }
        if(p1.Confronta(p2)==1){
            System.out.println(p1.getNome()+" guadagna di più di "+p2.getNome());
        }
        else{
            System.out.println(p2.getNome()+" guadagna di più di "+p1.getNome());
        }
        System.out.println("Calcoliamo l'età di "+p1.getNome()+ ":"+p1.Età());
        System.out.println("Calcoliamo l'età di "+p2.getNome()+":"+p2.Età());

        p1.Stampa();
        p2.Stampa();

    }
}